export class Fruta {
  id!: string;
  nombre!: string;
  precio!: number;
  unidades!: number;
  imagen!:string;
}
